$(document).ready(function() {



//masonry init
 	var $container = $('#js-masonry-animate');
	// initialize
	$container.masonry({
		itemSelector: '.js-masonry-item',
		columnWidth: '.masonry-sizer',
		gutter: 0
	});
		


});